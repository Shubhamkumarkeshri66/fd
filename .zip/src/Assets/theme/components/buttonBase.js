
const buttonBase = {
  defaultProps: {
    disableRipple: false,
  },
};

export default buttonBase;
