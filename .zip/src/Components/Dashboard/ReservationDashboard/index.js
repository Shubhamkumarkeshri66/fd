import React from "react";

const ReservationDashboard = () => {
  return <div>ReservationDashboard</div>;
};

export default ReservationDashboard;
