import React from "react";
import { Rooms } from "../../Rooms";

const RoomDisplayDashboard = () => {
  return (
    <>
      <Rooms />
    </>
  );
};

export default RoomDisplayDashboard;
