import React from 'react'

const RoomCheckOut = () => {
  return (
    <div>
      RoomCheckOut
    </div>
  )
}

export default RoomCheckOut
