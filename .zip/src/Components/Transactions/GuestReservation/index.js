import React from "react";

const GuestReservation = () => {
  return <div>GuestReservation</div>;
};

export default GuestReservation;
