import React from "react";

const PaymentReceipt = () => {
  return <div>PaymentReceipt</div>;
};

export default PaymentReceipt;
