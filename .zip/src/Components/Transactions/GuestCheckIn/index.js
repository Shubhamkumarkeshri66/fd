import React from "react";

const GuestCheckIn = () => {
  return <div>GuestCheckIn</div>;
};

export default GuestCheckIn;
