import React from "react";

const RoomChangeEntry = () => {
  return <div>RoomChangeEntry</div>;
};

export default RoomChangeEntry;
