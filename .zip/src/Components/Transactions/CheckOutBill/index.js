import React from "react";

const CheckOutBill = () => {
  return <div>CheckOutBill</div>;
};

export default CheckOutBill;
