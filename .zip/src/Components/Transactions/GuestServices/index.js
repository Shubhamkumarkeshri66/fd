import React from "react";

const GuestServices = () => {
  return <div>GuestServices</div>;
};

export default GuestServices;
