import React from 'react';
import { Box, Paper, Typography, CircularProgress, Button } from '@mui/material';

export function CustomerSatisfaction() {
  const rating = 3.5;
  const progress = (rating / 5) * 100;

  return (
    <Paper
      elevation={0}
      sx={{
        padding: 3,
        borderRadius: 2,
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: 2,
      }}
    >
      <Typography variant="h6">Customers Satisfaction</Typography>
      <Box
        sx={{
          position: 'relative',
          display: 'inline-flex',
        }}
      >
        <CircularProgress
          variant="determinate"
          value={progress}
          size={120}
          thickness={8}
          sx={{ color: 'primary.main' }}
        />
        <Box
          sx={{
            top: 0,
            left: 0,
            bottom: 0,
            right: 0,
            position: 'absolute',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <Typography variant="h4" component="div" color="primary">
            {rating}
          </Typography>
        </Box>
      </Box>
      <Typography variant="body2" color="text.secondary" align="center">
        Lorem ipsum is simply dummy text of the printing and typesetting industry.
      </Typography>
      <Button variant="contained" color="primary" fullWidth>
        Customers Review
      </Button>
    </Paper>
  );
}
