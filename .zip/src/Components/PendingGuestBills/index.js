import { Box, Typography } from "@mui/material";
import React from "react";

const PendingGuestBills = () => {
  return (
    <Box sx={{ p: 2 }}>
      <Typography>
        Pending.............# Api not Created (PendingGuestBills)
      </Typography>
    </Box>
  );
};

export default PendingGuestBills;
