import React from "react";
import { Grid, Paper, Typography, Box } from "@mui/material";
import LoginIcon from "@mui/icons-material/Login";
import LogoutIcon from "@mui/icons-material/Logout";
import BookOnlineIcon from "@mui/icons-material/BookOnline";
import HotelIcon from "@mui/icons-material/Hotel";
import LuggageIcon from "@mui/icons-material/Luggage";
import PaymentsIcon from "@mui/icons-material/Payments";
import { useNavigate } from "react-router-dom"; 

const cards = [
  {
    title: "Current Occupancy",
    value: "400",
    subtext: "Today",
    icon: <LoginIcon />,
    color: "#FF6B35",
    path: "/currentoccupancy",
  },
  {
    title: "Arrivals",
    value: "380",
    subtext: "Today",
    icon: <LogoutIcon />,
    color: "#38B6FF",
    path: "/arrivals",
  },
  {
    title: "Departures",
    value: "436",
    subtext: "Today",
    icon: <BookOnlineIcon />,
    color: "#1976D2",
    path: "/departures",
  },
  {
    title: "Expected Arrivals",
    value: "064",
    subtext: "Today",
    icon: <HotelIcon />,
    color: "#4CAF50",
    path: "/expectedarrivals",
  },
  {
    title: "Expected Departures",
    value: "064",
    subtext: "Today",
    icon: <LuggageIcon />,
    color: "#4CAF50",
    path: "/expecteddepartures",
  },
  {
    title: "Pending Guest Bills",
    value: "064",
    subtext: "On time",
    icon: <PaymentsIcon />,
    color: "#4CAF50",
    path: "/pendingguestbills",
  },
];

export function OverviewCards() {
  const navigate = useNavigate(); 

  const handleCardClick = (path) => {
    navigate(path); 
  };

  return (
    <Box sx={{ px: 2, py: 3 }}>
      <Grid container spacing={3}>
        {cards.map((card, index) => (
          <Grid item xs={12} sm={6} md={4} key={index}>
            <Paper
              onClick={() => handleCardClick(card.path)} 
              sx={{
                p: 2.5,
                borderRadius: 2,
                height: "120px", 
                width: "130px",
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                gap: 1,
                transition: "transform 0.3s, box-shadow 0.3s, background-color 0.3s",
                boxShadow: 2,
                cursor: "pointer",
                "&:hover": {
                  transform: "translateY(-5px)",
                  boxShadow: 4,
                  backgroundColor: "action.hover",
                },
              }}
            >
              <Box
                sx={{
                  backgroundColor: card.color,
                  borderRadius: "50%",
                  width: 50,
                  height: 50,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  transition: "background-color 0.3s",
                  "& svg": {
                    color: "white",
                    fontSize: "1.5rem",
                  },
                  "&:hover": {
                    backgroundColor: "#000",
                  },
                }}
              >
                {card.icon}
              </Box>
              <Typography
                variant="h5"
                fontWeight="bold"
                color="text.primary"
                textAlign="center"
              >
                {card.value}
              </Typography>
              <Typography
                variant="subtitle2"
                color="text.secondary"
                textAlign="center"
              >
                {card.title}
              </Typography>
              <Typography
                variant="caption"
                color="text.secondary"
                textAlign="center"
              >
                {card.subtext}
              </Typography>
            </Paper>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
}
